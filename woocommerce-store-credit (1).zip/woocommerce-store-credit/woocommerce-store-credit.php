<?php
/**
 * Plugin Name: WooCommerce Store Credit
 * Plugin URI: https://woocommerce.com/products/store-credit/
 * Description: Create "store credit" coupons for customers in your WooCommerce store which are redeemable at checkout. Also, generate and email store credit coupons to customers via the backend.
 * Version: 2.2.0
 * Author: WooCommerce
 * Author URI: https://woocommerce.com/
 * Requires at least: 4.1
 * Tested up to: 4.9
 * WC requires at least: 2.6
 * WC tested up to: 3.5
 * Woo: 18609:c4bf3ecec4146cb69081e5b28b6cdac4
 *
 * Copyright: 2014-2018 WooCommerce.
 * License: GNU General Public License v3.0
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 *
 * Adapted from the original store credit extension created by Visser Labs (http://visser.com.au)
 *
 * @package WC_Store_Credit
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Required functions
 */
if ( ! function_exists( 'woothemes_queue_update' ) ) {
	require_once 'woo-includes/woo-functions.php';
}

/**
 * Plugin updates
 */
woothemes_queue_update( plugin_basename( __FILE__ ), 'c4bf3ecec4146cb69081e5b28b6cdac4', '18609' );

if ( is_woocommerce_active() && ! class_exists( 'WC_Store_Credit_Plus' ) ) {

	/**
	 * Localisation
	 */
	load_plugin_textdomain( 'woocommerce-store-credit', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );

	/**
	 * WC_Store_Credit_Plus class
	 */
	class WC_Store_Credit_Plus {

		/**
		 * WooCommerce Store Credit version.
		 *
		 * @since 2.2.0
		 *
		 * @var string
		 */
		public $version = '2.2.0';

		/**
		 * Constructor
		 */
		public function __construct() {
			$this->define_constants();
			$this->includes();

			add_filter( 'woocommerce_coupon_is_valid', array( $this, 'coupon_is_valid' ), 10, 2 );
			add_filter( 'woocommerce_coupon_is_valid_for_cart', array( $this, 'coupon_is_valid_for_cart' ), 10, 2 );
			add_action( 'woocommerce_before_my_account', array( $this, 'display_credit' ) );
			add_filter( 'woocommerce_cart_totals_coupon_label', array( $this, 'cart_totals_coupon_label' ), 10, 2 );
			add_filter( 'woocommerce_coupon_discount_types', array( $this, 'add_discount_type' ) );
			add_action( 'woocommerce_loaded', array( $this, 'load_post_wc_class' ) );
		}

		/**
		 * Define WC Constants.
		 *
		 * @since 2.2.0
		 */
		private function define_constants() {
			$this->define( 'WC_STORE_CREDIT_VERSION', $this->version );
			$this->define( 'WC_STORE_CREDIT_PLUS_VERSION', $this->version ); // Backward compatibility.
			$this->define( 'WC_STORE_CREDIT_PLUGIN_DIR', untrailingslashit( plugin_dir_path( __FILE__ ) ) );
			$this->define( 'WC_STORE_CREDIT_PLUGIN_URL', untrailingslashit( plugin_dir_url( __FILE__ ) ) );
		}

		/**
		 * Define constant if not already set.
		 *
		 * @since 2.2.0
		 *
		 * @param string      $name  Constant name.
		 * @param string|bool $value Constant value.
		 */
		private function define( $name, $value ) {
			if ( ! defined( $name ) ) {
				define( $name, $value );
			}
		}

		/**
		 * Includes the necessary files.
		 *
		 * @since 2.2.0
		 */
		public function includes() {
			include_once 'includes/wc-store-credit-functions.php';
			include_once 'includes/class-wc-store-credit-apply-coupon.php';

			// Admin.
			if ( is_admin() ) {
				include_once 'includes/class-wc-store-credit-plus-admin.php';
			}
		}

		/**
		 * Loads any class that needs to check for WC loaded.
		 *
		 * @since 2.1.15
		 */
		public function load_post_wc_class() {
			if ( is_admin() ) {
				require_once( dirname( __FILE__ ) . '/includes/class-wc-store-credit-privacy.php' );
			}
		}

		/**
		 * Add the coupon type to admin
		 */
		public function add_discount_type( $discount_types ) {
			$discount_types['store_credit'] = __( 'Store Credit', 'woocommerce-store-credit' );
			return $discount_types;
		}

		/**
		 * Display credit
		 */
		public function display_credit() {
			if ( $coupons = $this->get_customer_credit() ) {
				?>
					<h2><?php _e( 'Store Credit', 'woocommerce-store-credit' ); ?></h2>
					<ul class="store-credit">
						<?php
						$html = '';
						foreach ( $coupons as $code ) {
							$coupon = new WC_Coupon( $code->post_title );
							if ( wc_is_store_credit_coupon( $coupon ) ) {
								$html .= '<li><strong>' . wc_store_credit_get_coupon_prop( $coupon, 'code' ) . '</strong> &mdash;' . wc_price( wc_store_credit_get_coupon_prop( $coupon, 'amount' ) ) . '</li>';
							}
						}

						if ( ! empty ( $html ) ) {
							echo $html;
						} else {
							echo '<li>' . __( 'You do not have any store credit on your account yet.', 'woocommerce-store-credit' ) . '</li>';
						}
						?>
					</ul>
				<?php
			}
		}

		/**
		 * Get credit for a customer
		 */
		public function get_customer_credit() {
			if ( 'no' === get_option( 'woocommerce_store_credit_show_my_account', 'yes' ) ) {
				return;
			}

			$user = wp_get_current_user();

			if ( '' === $user->user_email ) {
				return;
			}

			$args = array(
				'post_type'      => 'shop_coupon',
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'meta_query'     => array(
					array(
						'key'     => 'customer_email',
						'value'   => $user->user_email,
						'compare' => 'LIKE'
					),
					array(
						'key'     => 'coupon_amount',
						'value'   => '0',
						'compare' => '>=',
						'type'    => 'NUMERIC'
					)
				)
			);

			return get_posts( $args );
		}

		/**
		 * Check if credit is valid
		 */
		public function coupon_is_valid( $valid, $coupon ) {
			if ( $valid && wc_is_store_credit_coupon( $coupon ) && wc_store_credit_get_coupon_prop( $coupon, 'amount' ) <= 0 ) {
				wc_add_notice( __( 'There is no credit remaining on this coupon.', 'woocommerce-store-credit' ), 'error' );
				return false;
			}
			return $valid;
		}

		/**
		 * Check if credit is valid
		 */
		public function coupon_is_valid_for_cart( $valid, $coupon ) {
			if ( wc_is_store_credit_coupon( $coupon ) ) {
				return true;
			}

			return $valid;
		}

		/**
		 * Update a coupon after purchase.
		 *
		 * @deprecated 2.2.0 Moved to `WC_Store_Credit_Apply_Coupon->update_credit_amount`.
		 */
		public function update_credit_amount() {
			_deprecated_function( __METHOD__, '2.2.0', 'WC_Store_Credit->update_credit_amount' );
		}

		/**
		 * Get coupon discount amount.
		 *
		 * @since 2.0.0
		 * @deprecated 2.2.0
		 *
		 * @param  float $discount
		 * @param  float $discounting_amount
		 * @param  object $cart_item
		 * @param  bool $single
		 * @param  WC_Coupon $coupon
		 * @return float
		 */
		public function coupon_get_discount_amount( $discount, $discounting_amount, $cart_item, $single, $coupon ) {
			return $discount;
		}

		/**
		 * Do coupon post processing to fix discrepancy issues by smoothing
		 * values and adding the difference between what's currenty applied
		 * and what needs to be applied.
		 *
		 * @deprecated 2.2.0
		 *
		 * @param array     $discounts Currently applied discounts.
		 * @param WC_Coupon $coupon    Coupon used.
		 * @return array Newly applied discounts
		 */
		public function calculate_discrepancy( $discounts, $coupon ) {
			_deprecated_function( __METHOD__, '2.2.0' );

			return $discounts;
		}

		/**
		 * Change label in cart
		 *
		 * @param  string    $label  The coupon label.
		 * @param  WC_Coupon $coupon The coupon instance.
		 * @return string
		 */
		public function cart_totals_coupon_label( $label, $coupon ) {
			if ( wc_is_store_credit_coupon( $coupon ) ) {
				$label = __( 'Store credit:', 'woocommerce-store-credit' );
			}

			return $label;
		}

		/**
		 * If another discount is provided, the credit is moved to the "last applied" coupon.
		 *
		 * @deprecated 2.2.0 Moved to `WC_Store_Credit_Apply_Coupon->apply_coupon_last`.
		 *
		 * @param string $code The coupon code.
		 */
		public function apply_credit_last( $code ) {
			_deprecated_function( __METHOD__, '2.2.0', 'WC_Store_Credit_Apply_Coupon->apply_coupon_last' );
		}

		/**
		 * Makes it so we don't add a "Coupon code applied successfully" message for EVERY discount we add back.
		 *
		 * @deprecated 2.2.0
		 */
		public function hide_coupon_message( $msg, $msg_code, $coupon ) {
			_deprecated_function( __METHOD__, '2.2.0' );

			return '';
		}

		/**
		 * Get coupon property with compatibility for WC lt 3.0.
		 *
		 * @since 2.1.7
		 * @deprecated 2.2.0 Use the function `wc_store_credit_get_prop` instead.
		 *
		 * @param WC_Coupon $coupon Coupon object.
		 * @param string    $key    Coupon property.
		 *
		 * @return mixed Value of coupon property.
		 */
		public static function get_coupon_prop( $coupon, $key ) {
			_deprecated_function( __METHOD__, '2.2.0', 'wc_store_credit_get_prop' );

			return wc_store_credit_get_coupon_prop( $coupon, $key );
		}
	}

	new WC_Store_Credit_Plus();
}
