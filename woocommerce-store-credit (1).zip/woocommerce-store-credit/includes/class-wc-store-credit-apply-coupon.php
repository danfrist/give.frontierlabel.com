<?php
/**
 * Apply the 'store_credit' coupons.
 *
 * @package WC_Store_Credit/Classes
 * @since   2.2.0
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'WC_Store_Credit_Apply_Coupon' ) ) {

	/**
	 * Class WC_Store_Credit_Apply_Coupon
	 */
	class WC_Store_Credit_Apply_Coupon {

		/**
		 * Apply the coupon before taxes or not.
		 *
		 * @var bool
		 */
		protected $before_tax;

		/**
		 * The store_credit discounts grouped by coupon code.
		 *
		 * @var array
		 */
		protected $discounts = array();

		/**
		 * The store_credit total discounts.
		 *
		 * @var array
		 */
		protected $total_discounts = array();

		/**
		 * The cart item keys in pairs [index => key].
		 *
		 * Where the index is: '{product_id}_{variation_id}_{quantity}'.
		 *
		 * @var array
		 */
		protected $cart_item_keys;

		/**
		 * Constructor.
		 *
		 * @since 2.2.0
		 */
		public function __construct() {
			add_filter( 'woocommerce_coupon_sort', array( $this, 'set_coupon_priority' ), 10, 2 );
			add_action( 'woocommerce_applied_coupon', array( $this, 'apply_coupon_last' ) );
			add_filter( 'woocommerce_coupon_get_discount_amount', array( $this, 'coupon_get_discount_amount' ), 10, 5 );
			add_filter( 'woocommerce_coupon_custom_discounts_array', array( $this, 'coupon_get_discounts_array' ), 10, 2 );
			add_action( 'woocommerce_after_calculate_totals', array( $this, 'update_before_tax_coupons' ), 5 );
			add_action( 'woocommerce_after_calculate_totals', array( $this, 'after_calculate_totals' ) );
			add_action( 'woocommerce_new_order', array( $this, 'update_credit_amount' ), 8 );
		}

		/**
		 * Gets if the coupon should be applied before the taxes or not.
		 *
		 * @since 2.2.0
		 *
		 * @return bool
		 */
		public function apply_before_tax() {
			// Cache the result.
			if ( is_null( $this->before_tax ) ) {
				$this->before_tax = (
					wc_store_credit_allow_before_tax_option() &&
					'yes' === get_option( 'woocommerce_store_credit_apply_before_tax', 'no' )
				);
			}

			return $this->before_tax;
		}

		/**
		 * Initialize the cart information.
		 *
		 * @since 2.2.0
		 */
		public function init_cart() {
			$cart_item_keys = array();

			foreach ( WC()->cart->cart_contents as $cart_item_key => $values ) {
				$cart_item_index = $this->get_cart_item_index( $values );

				$cart_item_keys[ $cart_item_index ] = $cart_item_key;
			}

			$this->cart_item_keys = $cart_item_keys;
		}

		/**
		 * Gets the index used to identify a cart item.
		 *
		 * @since 2.2.0
		 *
		 * @param array $cart_item The cart item data.
		 * @return string
		 */
		public function get_cart_item_index( $cart_item ) {
			return "{$cart_item['product_id']}_{$cart_item['variation_id']}_{$cart_item['quantity']}";
		}

		/**
		 * Gets the cart item key for the specified cart item.
		 *
		 * @since 2.2.0
		 *
		 * @param array $cart_item The cart item data.
		 * @return string|false The cart item key. False otherwise.
		 */
		public function get_cart_item_key( $cart_item ) {
			if ( isset( $cart_item['key'] ) ) {
				return $cart_item['key'];
			}

			// Cache the result.
			if ( is_null( $this->cart_item_keys ) ) {
				$this->init_cart();
			}

			$cart_item_index = $this->get_cart_item_index( $cart_item );

			return ( isset( $this->cart_item_keys[ $cart_item_index ] ) ? $this->cart_item_keys[ $cart_item_index ] : false );
		}

		/**
		 * Gets the coupon code.
		 *
		 * @since 2.2.0
		 *
		 * @param mixed $the_coupon The coupon code or the coupon instance.
		 * @return string
		 */
		public function get_coupon_code( $the_coupon ) {
			return ( $the_coupon instanceof WC_Coupon ? wc_store_credit_get_coupon_prop( $the_coupon, 'code' ) : $the_coupon );
		}

		/**
		 * Gets all the discounts applied by the specified coupon.
		 *
		 * @since 2.2.0
		 *
		 * @param mixed $the_coupon The coupon code or the coupon instance.
		 * @return array An array with the discounts by item.
		 */
		public function get_discounts_for_coupon( $the_coupon ) {
			$coupon_code = $this->get_coupon_code( $the_coupon );

			return ( isset( $this->discounts[ $coupon_code ] ) ? $this->discounts[ $coupon_code ] : array() );
		}

		/**
		 * Gets the discount applied to the item by the specified coupon.
		 *
		 * @since 2.2.0
		 *
		 * @param mixed  $the_coupon The coupon code or the coupon instance.
		 * @param string $item_key   The item key.
		 * @return float|false The item discount. False otherwise.
		 */
		public function get_discount_for_item( $the_coupon, $item_key ) {
			$discounts = $this->get_discounts_for_coupon( $the_coupon );

			if ( isset( $discounts[ $item_key ] ) ) {
				return $discounts[ $item_key ];
			}

			return false;
		}

		/**
		 * Sets the discount applied to the item by the specified coupon.
		 *
		 * @since 2.2.0
		 *
		 * @param mixed  $the_coupon The coupon code or the coupon instance.
		 * @param string $item_key   The item key.
		 * @param float  $discount   The discount to apply.
		 */
		public function set_discount_for_item( $the_coupon, $item_key, $discount ) {
			$coupon_code = $this->get_coupon_code( $the_coupon );
			$discounts   = $this->get_discounts_for_coupon( $the_coupon );

			$discounts[ $item_key ] = $discount;

			$this->discounts[ $coupon_code ] = $discounts;
		}

		/**
		 * Gets the remained coupon amount.
		 *
		 * @since 2.2.0
		 *
		 * @param WC_Coupon $the_coupon The coupon instance.
		 * @return float
		 */
		public function get_remained_coupon_amount( $the_coupon ) {
			$coupon_amount = wc_store_credit_get_coupon_prop( $the_coupon, 'amount' );
			$discounts     = $this->get_discounts_for_coupon( $the_coupon );

			return $coupon_amount - array_sum( $discounts );
		}

		/**
		 * Sets the coupon priority.
		 *
		 * @since 2.2.0
		 *
		 * @param int       $priority The coupon priority.
		 * @param WC_Coupon $coupon   The coupon instance.
		 * @return int
		 */
		public function set_coupon_priority( $priority, $coupon ) {
			// Process the store_credit coupons after all the other kinds of coupons.
			if ( wc_is_store_credit_coupon( $coupon ) ) {
				$priority = 4;
			}

			return $priority;
		}

		/**
		 * Moves the 'store_credit' coupons at the end of the list.
		 *
		 * @since 2.2.0
		 *
		 * @param string $coupon_code The coupon code.
		 */
		public function apply_coupon_last( $coupon_code ) {
			$coupon = new WC_Coupon( $coupon_code );

			if ( wc_is_store_credit_coupon( $coupon ) ) {
				return;
			}

			$applied_coupons = WC()->cart->get_applied_coupons();

			if ( empty( $applied_coupons ) ) {
				return;
			}

			$codes_to_add_back = array();

			foreach ( $applied_coupons as $applied_coupon_index => $applied_coupon_code ) {
				$applied_coupon = new WC_Coupon( $applied_coupon_code );

				if ( wc_is_store_credit_coupon( $applied_coupon ) ) {
					WC()->cart->remove_coupon( $applied_coupon_code );
					$codes_to_add_back[] = $applied_coupon_code;
				}
			}

			add_filter( 'woocommerce_coupon_message', '__return_empty_string' );

			foreach ( $codes_to_add_back as $code_to_add_back ) {
				WC()->cart->add_discount( $code_to_add_back );
			}

			remove_filter( 'woocommerce_coupon_message', '__return_empty_string' );
		}

		/**
		 * Gets coupon discount amount before calculating the taxes.
		 *
		 * @since 2.2.0
		 *
		 * @param float      $discount           The coupon discount.
		 * @param float      $discounting_amount Amount the coupon is being applied to.
		 * @param array|null $cart_item          Cart item being discounted if applicable.
		 * @param boolean    $single             True if discounting a single qty item, false if its the line.
		 * @param WC_Coupon  $coupon             The coupon instance.
		 * @return float Amount this coupon has discounted.
		 */
		public function coupon_get_discount_amount( $discount, $discounting_amount, $cart_item, $single, $coupon ) {
			if ( ! wc_is_store_credit_coupon( $coupon ) || ! $this->apply_before_tax() ) {
				return $discount;
			}

			/*
			 * Return the maximum amount to obtain the total discount for this coupon and fix the discounts per item
			 * in the 'woocommerce_coupon_custom_discounts_array' filter hook.
			 */
			if ( version_compare( WC()->version, '3.4', '>=' ) ) {
				return $discounting_amount;
			}

			$cart_item_key = $this->get_cart_item_key( $cart_item );

			if ( false === $cart_item_key ) {
				return $discounting_amount;
			}

			// Checks if the discount was calculated previously.
			$discount = $this->get_discount_for_item( $coupon, $cart_item_key );

			if ( false !== $discount ) {
				return $discount;
			}

			$coupon_code = wc_store_credit_get_coupon_prop( $coupon, 'code' );

			// Calculate the discount as a percent of the total discount.
			if ( isset( $this->total_discounts[ $coupon_code ] ) ) {
				$total_discount = $this->total_discounts[ $coupon_code ];
				$item_quantity  = ( isset( $cart_item['quantity'] ) ? (int) $cart_item['quantity'] : 1 );

				if ( version_compare( WC()->version, '3.2', '<' ) ) {
					$discounting_amount = ( $discounting_amount * $item_quantity );
				}

				$coupon_amount = wc_store_credit_get_coupon_prop( $coupon, 'amount' );
				$coupon_amount = min( $coupon_amount, $total_discount );

				$discount_percent = ( $discounting_amount / $total_discount );

				$discount = ( (float) $coupon_amount * $discount_percent );
				$discount = ( min( $discount, $discounting_amount ) / $item_quantity );

				// Cache the discount.
				$this->set_discount_for_item( $coupon, $cart_item_key, $discount );

				return $discount;
			}

			/*
			 * Return the maximum amount to obtain the total discount for this coupon and fix the discounts per item
			 * in the second iteration after execute the method 'update_before_tax_coupons'.
			 */
			return $discounting_amount;
		}

		/**
		 * Post-process the coupon discounts.
		 *
		 * @since 2.2.0
		 *
		 * @param array     $discounts An array with the applied discounts per item.
		 * @param WC_Coupon $coupon    The coupon instance.
		 * @return array
		 */
		public function coupon_get_discounts_array( $discounts, $coupon ) {
			if ( ! wc_is_store_credit_coupon( $coupon ) || ! $this->apply_before_tax() ) {
				return $discounts;
			}

			$subtotal      = array_sum( $discounts );
			$coupon_amount = wc_store_credit_get_coupon_prop( $coupon, 'amount' );

			foreach ( $discounts as $cart_item_key => $discounting_amount ) {
				// Checks if the discount was calculated previously.
				$discount = $this->get_discount_for_item( $coupon, $cart_item_key );

				if ( false === $discount ) {
					$discount_percent = $discounting_amount / $subtotal;

					$discount = wc_add_number_precision( (float) $coupon_amount * $discount_percent );
					$discount = min( $discount, $discounting_amount );

					// Cache the discount.
					$this->set_discount_for_item( $coupon, $cart_item_key, wc_remove_number_precision( $discount ) );
				} else {
					$discount = wc_add_number_precision( $discount );
				}

				$discounts[ $cart_item_key ] = $discount;
			}

			return $discounts;
		}

		/**
		 * Updates the discount of the Store Credit coupons before taxes.
		 *
		 * @since 2.2.0
		 */
		public function update_before_tax_coupons() {
			if ( version_compare( WC()->version, '3.4', '>=' ) || ! $this->apply_before_tax() ) {
				return;
			}

			$discounts = wc_store_credit_get_coupon_discount_totals();

			add_filter( 'woocommerce_coupon_message', '__return_empty_string' );

			foreach ( $discounts as $coupon_code => $discount ) {
				$coupon = new WC_Coupon( $coupon_code );

				if ( ! wc_is_store_credit_coupon( $coupon ) ) {
					continue;
				}

				$this->total_discounts[ $coupon_code ] = $discount;

				$coupon_discounts = $this->get_discounts_for_coupon( $coupon );

				// Not calculated correctly. Re-add it now that we know the subtotal.
				if ( empty( $coupon_discounts ) ) {
					WC()->cart->remove_coupon( $coupon_code );
					WC()->cart->add_discount( $coupon_code );

					// Re-add one coupon each time.
					break;
				}
			}

			remove_filter( 'woocommerce_coupon_message', '__return_empty_string' );
		}

		/**
		 * Applies the 'store_credit' coupons to the cart totals after calculating the taxes.
		 *
		 * @since 2.2.0
		 *
		 * @param WC_Cart $cart The cart instance.
		 */
		public function after_calculate_totals( $cart ) {
			if ( $this->apply_before_tax() ) {
				return;
			}

			$cart_total = wc_store_credit_get_cart_total( $cart );

			if ( empty( $cart_total ) ) {
				return;
			}

			$total           = $cart_total;
			$applied_coupons = WC()->cart->get_applied_coupons();

			foreach ( $applied_coupons as $coupon_code ) {
				$coupon = new WC_Coupon( $coupon_code );

				if ( ! $coupon || ! wc_is_store_credit_coupon( $coupon ) ) {
					continue;
				}

				$coupon_amount = wc_store_credit_get_coupon_prop( $coupon, 'amount' );
				$discount      = min( $total, $coupon_amount );

				$total -= $discount;

				$this->update_coupon_discount_total( $coupon, $discount );
			}

			wc_store_credit_set_cart_total( $total, $cart );
		}

		/**
		 * Updates the coupon discount in the cart instance.
		 *
		 * @since 2.2.0
		 *
		 * @param WC_Coupon $coupon   The coupon Instance.
		 * @param float     $discount The discount.
		 */
		public function update_coupon_discount_total( $coupon, $discount ) {
			$coupon_code = wc_store_credit_get_coupon_prop( $coupon, 'code' );

			$coupon_discount_totals = wc_store_credit_get_coupon_discount_totals();

			if ( empty( $coupon_discount_totals[ $coupon_code ] ) ) {
				$coupon_discount_totals[ $coupon_code ] = $discount;
			} else {
				$coupon_discount_totals[ $coupon_code ] += $discount;
			}

			wc_store_credit_set_coupon_discount_totals( $coupon_discount_totals );
		}

		/**
		 * Updates 'store_credit' coupons after purchase.
		 *
		 * @since 2.2.0
		 *
		 * @param int $order_id The order id.
		 */
		public function update_credit_amount( $order_id ) {
			if ( empty( WC()->cart ) ) {
				return;
			}

			$applied_coupons = WC()->cart->get_applied_coupons();

			if ( empty( $applied_coupons ) ) {
				return;
			}

			$store_credit_used      = array();
			$coupon_discount_totals = wc_store_credit_get_coupon_discount_totals();

			foreach ( $applied_coupons as $coupon_code ) {
				$coupon = new WC_Coupon( $coupon_code );

				if ( ! $coupon || ! wc_is_store_credit_coupon( $coupon ) ) {
					continue;
				}

				$discount = ( isset( $coupon_discount_totals[ $coupon_code ] ) ? $coupon_discount_totals[ $coupon_code ] : 0 );

				if ( $discount > 0 ) {
					$store_credit_used[ $coupon_code ] = $discount;

					$credit_remaining = max( 0, ( wc_store_credit_get_coupon_prop( $coupon, 'amount' ) - $discount ) );

					if ( $credit_remaining <= 0 && 'yes' === get_option( 'woocommerce_delete_store_credit_after_usage', 'yes' ) ) {
						wp_trash_post( wc_store_credit_get_coupon_prop( $coupon, 'id' ) );
					} else {
						update_post_meta( wc_store_credit_get_coupon_prop( $coupon, 'id' ), 'coupon_amount', wc_format_decimal( $credit_remaining, 2 ) );
					}
				}
			}

			// Save the used store credit on this purchase.
			if ( ! empty( $store_credit_used ) ) {
				add_post_meta( $order_id, '_store_credit_used', $store_credit_used );
			}
		}
	}
}

new WC_Store_Credit_Apply_Coupon();
