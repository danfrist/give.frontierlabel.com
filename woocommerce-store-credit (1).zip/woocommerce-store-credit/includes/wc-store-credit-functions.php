<?php
/**
 * Useful functions for the plugin
 *
 * @package WC_Store_Credit/Functions
 * @since   2.2.0
 */

defined( 'ABSPATH' ) || exit;

// Include core functions.
require 'wc-store-credit-compatibility-functions.php';

/**
 * Gets if it's a 'store_credit' coupon or not.
 *
 * @since 2.2.0
 *
 * @param WC_Coupon $coupon The coupon instance.
 * @return bool
 */
function wc_is_store_credit_coupon( $coupon ) {
	return $coupon->is_type( 'store_credit' );
}

/**
 * Gets if the option to apply the discount before taxes is available or not.
 *
 * @since 2.2.0
 *
 * @return bool
 */
function wc_store_credit_allow_before_tax_option() {
	return wc_tax_enabled();
}
