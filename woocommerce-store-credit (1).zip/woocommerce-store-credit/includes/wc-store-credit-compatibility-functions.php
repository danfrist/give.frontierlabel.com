<?php
/**
 * Backward compatibility functions
 *
 * @package WC_Store_Credit/Functions
 * @since   2.2.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Gets a coupon property.
 *
 * @since 2.2.0
 *
 * @param WC_Coupon $coupon Coupon object.
 * @param string    $key    Coupon property.
 * @return mixed Value of coupon property.
 */
function wc_store_credit_get_coupon_prop( $coupon, $key ) {
	switch ( $key ) {
		case 'type':
			$getter = array( $coupon, 'get_discount_type' );
			break;
		default:
			$getter = array( $coupon, 'get_' . $key );
			break;
	}

	return is_callable( $getter ) ? call_user_func( $getter ) : $coupon->{ $key };
}

/**
 * Gets the cart total.
 *
 * @since 2.2.0
 *
 * @param mixed $cart Optional. The WC_Cart instance.
 * @return float
 */
function wc_store_credit_get_cart_total( $cart = null ) {
	if ( is_null( $cart ) ) {
		$cart = WC()->cart;
	}

	if ( version_compare( WC()->version, '3.1.2', '>' ) ) {
		$cart_total = $cart->get_total( 'edit' );
	} else {
		$cart_total = $cart->total;
	}

	return $cart_total;
}

/**
 * Sets the cart total.
 *
 * @since 2.2.0
 *
 * @param float $total The total amount.
 * @param mixed $cart Optional. The WC_Cart instance.
 */
function wc_store_credit_set_cart_total( $total, $cart = null ) {
	if ( is_null( $cart ) ) {
		$cart = WC()->cart;
	}

	if ( method_exists( $cart, 'set_total' ) ) {
		$cart->set_total( $total );
	} else {
		$cart->total = $total;
	}
}

/**
 * Gets the coupon discount totals.
 *
 * @since 2.2.0
 *
 * @return array
 */
function wc_store_credit_get_coupon_discount_totals() {
	if ( method_exists( WC()->cart, 'get_coupon_discount_totals' ) ) {
		$coupon_discount_totals = WC()->cart->get_coupon_discount_totals();
	} else {
		$coupon_discount_totals = ( isset( WC()->cart->coupon_discount_amounts ) ? WC()->cart->coupon_discount_amounts : array() );
	}

	return $coupon_discount_totals;
}

/**
 * Sets the coupon discount totals.
 *
 * @since 2.2.0
 *
 * @param array $coupon_discount_totals The total discounts.
 */
function wc_store_credit_set_coupon_discount_totals( $coupon_discount_totals ) {
	if ( method_exists( WC()->cart, 'set_coupon_discount_totals' ) ) {
		WC()->cart->set_coupon_discount_totals( $coupon_discount_totals );
	} else {
		WC()->cart->coupon_discount_amounts = $coupon_discount_totals;
	}
}
