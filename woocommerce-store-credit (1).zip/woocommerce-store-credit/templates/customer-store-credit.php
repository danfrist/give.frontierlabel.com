<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

<?php do_action( 'woocommerce_email_header', $email_heading ); ?>

<p>Because of your partnership with us, we are able to accomplish our purpose of Advancing the Kingdom of Jesus Christ. Thank you for your support!<br/></p>

<p><?php echo sprintf( __( "To use your credit enter the following code during checkout:", 'woocommerce-store-credit' ), $blogname ); ?></p>

<h2><?php echo $coupon_code; ?></h2>

<p>Go to <a href="https://give.frontierlabel.com">https://give.frontierlabel.com</a> to start giving now!</p>

<div style="clear:both;"></div>

<?php do_action( 'woocommerce_email_footer' ); ?>