=== WooCommerce Store Credit ===
Contributors: woocommerce, themesquad
Tags: woocommerce, credit, coupons
Requires at least: 4.1
Tested up to: 4.9
Stable tag: 2.2.0
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html
WC requires at least: 2.6
WC tested up to: 3.5
Woo: 18609:c4bf3ecec4146cb69081e5b28b6cdac4

Create 'Store Credit' coupons for customers in your WooCommerce store which are redeemable at checkout.

== Installation ==

1. Unzip and upload the plugin’s folder to your /wp-content/plugins/ directory.
2. Activate the extension through the ‘Plugins’ menu in WordPress.
3. Go to WooCommerce > Settings > General to configure the plugin.

== Documentation & support ==

Visit our [Product page](http://docs.woocommerce.com/document/woocommerce-store-credit/) to read the documentation and get support.

== Changelog ==

= 2.2.0 October 30, 2018 =
* Feature - Rewritten the way the Store Credit coupons are applied.
* Tweak - Save the used store credit on each purchase.
* Tweak - Define the constants if not already set.
* Fix - Fixed incorrect 'Store Credit' discounts when applied in combination with other coupons.
* Fix - PHP notice for undefined index.
* Fix - Remaining credit amount not correct when using taxes.
* Fix - Removed the use of the third parameter in the 'array_filter' function (Require PHP 5.6+).
* Dev - Added constant 'WC_STORE_CREDIT_VERSION'.

== Upgrade Notice ==

= 2.2 =
2.2 is a major update. It is important that you make backups and ensure you have installed WC 2.6+ before upgrading.
